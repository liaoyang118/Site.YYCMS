﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;
using System.Web;

namespace GenerateHtml
{
    /// <summary>
    /// 获取视图引擎渲染后的内容，生成静态化页面
    /// </summary>
    public class GeneratedController : Controller
    {

        public ActionResult Index()
        {
            string tempFilePath = "~/Views/Template/index.cshtml";
            string generatePath = "~/Views/Generated/index.cshtml";

            ViewData["list"] = "asdfsdf";
            TempData["tempList"] = "fgdfgdsdfsfd";

            return this.GeneratePage(tempFilePath, generatePath, this.ViewData, this.TempData, this.ControllerContext);
        }

        #region 1.1 生成静态页面 - GeneratePage
        /// <summary>
        /// 生成静态页面
        /// </summary>
        /// <param name="tempFilePath">模板文件全路径</param>
        /// <param name="generatePath">生成文件全路径</param>
        /// <param name="dic">ViewData</param>
        /// <param name="tempDic">TempData</param>
        /// <param name="context">控制器上下文</param>
        /// <returns></returns>
        private ActionResult GeneratePage(string tempFilePath, string generatePath, ViewDataDictionary dic, TempDataDictionary tempDic, ControllerContext context)
        {
            string fullPath = Server.MapPath(tempFilePath);
            if (!System.IO.File.Exists(fullPath))
            {
                return Json(new { success = false, errors = new { text = "不存在该文件" } }, "text/html", JsonRequestBehavior.AllowGet);
            }
            string html = GenerateHtml(tempFilePath, dic, tempDic, context);

            string error;
            bool isSuccess = CreatePage(generatePath, html, out error);
            return Json(new { success = isSuccess, errors = new { text = error } }, "text/html", JsonRequestBehavior.AllowGet);
        }
        
        #endregion

        #region 1.2 获取通过视图引擎渲染后的页面HTML文本 - GenerateHtml
        /// <summary>
        /// 获取通过视图引擎渲染后的页面HTML文本
        /// </summary>
        /// <param name="tempFilePath"></param>
        /// <param name="dic"></param>
        /// <param name="tempDic"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        private string GenerateHtml(string tempFilePath, ViewDataDictionary dic, TempDataDictionary tempDic, ControllerContext context)
        {
            string html = string.Empty;
            IView view = ViewEngines.Engines.FindView(context, tempFilePath, string.Empty).View;

            using (System.IO.StringWriter sw = new System.IO.StringWriter())
            {
                ViewContext vc = new ViewContext(context, view, dic, tempDic, sw);
                vc.View.Render(vc, sw);
                html = sw.ToString();
            }
            return html;
        } 
        #endregion

        #region 1.3 生成页面文件 - CreatePage
        /// <summary>
        /// 生成页面文件
        /// </summary>
        /// <param name="generatePath">生成文件的全路径</param>
        /// <param name="content">生成的页面内容</param>
        /// <param name="error"></param>
        /// <returns></returns>
        private bool CreatePage(string generatePath, string content, out string error)
        {
            error = string.Empty;
            try
            {

                string fullPath = Server.MapPath(generatePath);
                int _index = fullPath.LastIndexOf(@"\");
                string directoryPath = fullPath.Substring(0, _index);
                if (!System.IO.Directory.Exists(directoryPath))
                {
                    System.IO.Directory.CreateDirectory(directoryPath);
                }
                byte[] bytes = System.Text.Encoding.UTF8.GetBytes(content);
                using (System.IO.FileStream fs = new System.IO.FileStream(fullPath, System.IO.FileMode.OpenOrCreate))
                {
                    fs.Write(bytes, 0, bytes.Length);
                }
                return true;
            }
            catch (Exception ex)
            {
                error = ex.Message;
                return false;
            }

        } 
        #endregion
    }
}
